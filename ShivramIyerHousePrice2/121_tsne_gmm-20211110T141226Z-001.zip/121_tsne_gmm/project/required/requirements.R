install.packages('data.table')
install.packages('ggplot2')
install.packages('Rtsne')
install.packages('ClusterR')
