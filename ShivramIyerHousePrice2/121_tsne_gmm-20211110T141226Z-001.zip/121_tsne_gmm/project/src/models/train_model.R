# libraries ---------------------------------------------------------------

library(data.table)
library(ggplot2)
library(Rtsne)
library(ClusterR)

# load data ---------------------------------------------------------------

data <- fread("./project/volume/data/raw/data.csv")

# remove party ------------------------------------------------------------
# since we were not supposed to know it from data
# [party] corresponds to [breed_#] in your project

party <- data$party
data$party <- NULL

id <- data$id
data$id <- NULL

# principal component analysis --------------------------------------------

pca <- prcomp(data)

### use the unclass() function to get the data in PC space
pca_dt <- data.table(unclass(pca)$x)

# t-SNE -------------------------------------------------------------------

set.seed(1)
### I set seed before running Rtsne because it's a randomized algorithm

### run t-sne on the PCAs
### pca is built into Rtsne
### I run it seperately to see the internal steps
tsne <- Rtsne(pca_dt, dim=2, perplexity=5, pca=F, check_duplicates=F)
#tsne <- Rtsne(data, dim=2, perplexity=5, pca=T, check_duplicates=F)

### you may want to work with other tuning parameters as well
### here are some key tuning parameters
?Rtsne
### dims=[1-3] : dimension of low-dimensional features
### perplexity : Perplexity parameter
### pca=[T/F] : whether to do pca by itself
### pca_center=[T/F] : whether to center data points
### normalize=[T/F] : whether to normalize data points

# see results -------------------------------------------------------------
# which is not possible in your project since you don't know the truth

### grab out the coordinates
tsne_dt <- data.table(tsne$Y)

### add back in [party] and [Cats] so we can see what the analysis did with them
tsne_dt$party <- party
tsne_dt$cats <- data$Cats

### plot
ggplot(tsne_dt,aes(x=V1,y=V2,col=party)) + geom_point()
### in this case, I have access to party so I can see that it seems to have worked
### but you do not have access to species so you will just be plotting in black
### to see if there are groups

# GMM ---------------------------------------------------------------------
# use a gaussian mixture model to find optimal k
# then get probability of membership for each row to each group

k_bic <- Optimal_Clusters_GMM(tsne_dt[,.(V1,V2)], max_clusters=10, criterion="BIC")
### this fits a gmm to the data for all k=1 to k=max_clusters
### we then look for a major change in likelihood between k values

### now we will look at the change in model fit between successive k values
delta_k <- c(NA, k_bic[-1]-k_bic[-length(k_bic)])

### I'm going to make a plot so you can see the values
### this part isn't necessary
del_k_tab <- data.table(delta_k=delta_k, k=1:length(delta_k))

### plot 
ggplot(del_k_tab,aes(x=k,y=-delta_k)) +
  geom_point() + geom_line() +
  scale_x_continuous(breaks=scales::pretty_breaks(n=10)) +
  geom_text(aes(label=k), hjust=0, vjust=-1)

### now we run the model with our chosen k value
opt_k <- 2
gmm_data <- GMM(tsne_dt[,.(V1,V2)],opt_k)

# prediction --------------------------------------------------------------
# you should figure out the groups
# by looking at where sample_[1-3] belongs to

### the model gives a log-likelihood for each data point's membership to each cluster
### we need to convert log-likelihood into probability
l_clust <- gmm_data$Log_likelihood^(-10)
l_clust <- data.table(l_clust)
prob <- l_clust/rowSums(l_clust)

### we can now plot to see how cluster 1 looks
tsne_dt$Cluster_1_prob <- prob$V1
ggplot(tsne_dt,aes(x=V1,y=V2,col=Cluster_1_prob)) + geom_point()

### see the predicted probabilities
prob
### For the 1st sample which belongs to Republican, prob$V1 is larger than prob$V2
### So prob$V1 is the probability for R

# make submission ---------------------------------------------------------

submit <- data.table(id=id, party_D=prob$V2, party_R=prob$V1)
fwrite(submit,"./project/volume/data/processed/submit.csv")
